import{b3 as o,W as a,b4 as r}from"./index-DHtcqsoC.js";function b(){r({variableName:a("scrollbar.width").name})}function c(){o({variableName:a("scrollbar.width").name})}export{b,c as u};
